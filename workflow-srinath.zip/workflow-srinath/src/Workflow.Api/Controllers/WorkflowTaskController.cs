﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Workflow.Core.Domain;
using Workflow.Services.Interfaces;

namespace Workflow.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WorkFlowTaskController
        : ControllerBase
    {
        #region Constructor

        public WorkFlowTaskController(IWorkflowTaskService workflowTaskService)
        {
            _workflowTaskService = workflowTaskService;
        }

        #endregion


        #region Private Properties

        private IWorkflowTaskService _workflowTaskService;

        #endregion


        #region Public Methods

        [HttpGet("{id}")]
        public async Task<WorkflowTask> Get(Guid id)
        {
            return await _workflowTaskService.GetWorkflowTaskById(id);
        }


        [HttpPost]
        public async Task Post([FromBody] WorkflowTask task)
        {
            await _workflowTaskService.AddTask(task);
        }


        [HttpPut("{id}")]
        public async Task Put(string id, [FromBody] WorkflowTask task)
        {
            await _workflowTaskService.UpdateTask(task);
        }


        [HttpDelete("{id}")]
        public async Task Delete(Guid id)
        {
            await _workflowTaskService.RemoveTask(id);
        }


        [HttpGet("{id}/tasks")]
        public async Task<IEnumerable<WorkflowTask>> GetWorkflowTasksForUser(Guid id)
        {
            return await _workflowTaskService.GetWorkflowTasksForUser(id);
        }

        #endregion
    }
}
