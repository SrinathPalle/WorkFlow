﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Workflow.Core.Domain;
using Workflow.Services.Interfaces;

namespace Workflow.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController
        : ControllerBase
    {

        #region Constructor

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        #endregion


        #region Private Properties

        private IUserService _userService;

        #endregion


        #region Public Properties

        [HttpGet("{id}")]
        public async Task<ActionResult<UserTable>> Get(Guid id)
        {
            try
            {
                return Ok(await _userService.GetUserById(id));
            }
            catch (Exception e)
            {
                return BadRequest();
            }
        }
        [HttpGet("{email}/email")]
        public async Task<ActionResult<UserTable>> GetUserEmail(string email)
        {
            try
            {
                return Ok(await _userService.GetUserEmail(email));
            }
            catch (Exception e)
            {
                return BadRequest();
            }
        }
        [HttpGet("{firstName}/{lastName}")]
        public async Task<ActionResult<UserTable>> GetUserName(string firstName, string lastName)
        {
            try
            {
                return Ok(await _userService.GetUserName(firstName, lastName));
            }
            catch (Exception e)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        public async Task Post([FromBody] UserTable user)
        {
            await _userService.AddUser(user);
        }


        [HttpPut("{id}")]
        public async Task Put(string id, [FromBody] UserTable user)
        {
            await _userService.UpdateUser(user);
        }


        [HttpDelete("{id}")]
        public async Task Delete(Guid id)
        {
            await _userService.RemoveUser(id);
        }

        #endregion
    }
}
