﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Workflow.Core.Domain;

namespace Workflow.Services.Interfaces
{
    public interface IWorkflowTaskService
    {
        Task<WorkflowTask> GetWorkflowTaskById(Guid workflowTaskId);

        Task AddTask(WorkflowTask workflowTask);

        Task UpdateTask(WorkflowTask workflowTask);

        Task RemoveTask(Guid workflowTaskId);

        Task<IEnumerable<WorkflowTask>> GetWorkflowTasksForUser(Guid userId);
    }
}