﻿using System;
using System.Threading.Tasks;
using Workflow.Core.Domain;

namespace Workflow.Services.Interfaces
{
    public interface IUserService
    {
        Task<UserTable> GetUserById(Guid userId);
        Task<UserTable> GetUserEmail(string email);
        Task<UserTable> GetUserName(string firstName, string lastName);

        Task AddUser(UserTable user);

        Task UpdateUser(UserTable user);

        Task RemoveUser(Guid userId);
    }
}