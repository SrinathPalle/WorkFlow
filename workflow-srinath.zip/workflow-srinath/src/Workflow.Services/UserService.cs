﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using Workflow.Core.Domain;
using Workflow.Data;
using Workflow.Services.Interfaces;

namespace Workflow.Services
{
    public class UserService
        : IUserService
    {

        #region Constructor

        public UserService(WorkflowDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion


        #region Private Methods

        private readonly WorkflowDbContext _dbContext;

        #endregion


        #region Public Methods

        public async Task<UserTable> GetUserById(Guid userId)
        {
            var user = await _dbContext.Users
                .FirstOrDefaultAsync(x => x.Id == userId);

            return user;
        }


        public Task<UserTable> GetUserEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                throw new ArgumentNullException(nameof(email));
            }

            return userDetails(email);
        }
        public Task<UserTable> GetUserName(string firstName, string lastName)
        {
            if (string.IsNullOrWhiteSpace(firstName) && string.IsNullOrWhiteSpace(lastName))
            {
                throw new ArgumentNullException(nameof(firstName));
            }

            return userDetails(firstName, lastName);
        }

        private async Task<UserTable> userDetails(string email)
        {
            return await _dbContext.Users
                             .FirstOrDefaultAsync(x => x.Email == email);
        }

        private async Task<UserTable> userDetails(string firstName, string lastName)
        {
            return await _dbContext.Users
                             .FirstOrDefaultAsync(x => x.Firstname == firstName && x.Lastname==lastName);
        }

        public Task AddUser(UserTable user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            return SaveUser(user);
        }

        private async Task SaveUser(UserTable user)
        {
            await _dbContext.Users.AddAsync(user);
            await _dbContext.SaveChangesAsync();
        }

        public Task UpdateUser(UserTable user)
        {
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }

            return UpdateUserById(user);
        }

        private async Task UpdateUserById(UserTable user)
        {
            if (GetUserById(user.Id) != null)
            {
                UserTable ut = _dbContext.Users.First(x => x.Id.Equals(user.Id));
                ut.Firstname = user.Firstname;
                ut.Lastname = user.Lastname;
                ut.Email = user.Email;
                await _dbContext.SaveChangesAsync();
            }
        }


        public async Task RemoveUser(Guid userId)
        {
            if (GetUserById(userId) != null)
            {
                UserTable ut = _dbContext.Users.First(x => x.Id.Equals(userId));
                _dbContext.Users.Remove(ut);
                await _dbContext.SaveChangesAsync();
            }
        }

        #endregion
    }
}
