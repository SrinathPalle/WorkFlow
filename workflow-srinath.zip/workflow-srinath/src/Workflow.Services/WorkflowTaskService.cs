﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Workflow.Core.Domain;
using Workflow.Data;
using Workflow.Services.Interfaces;

namespace Workflow.Services
{
    public class WorkflowTaskService
        : IWorkflowTaskService
    {

        #region Constructor

        public WorkflowTaskService(WorkflowDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion


        #region Private Properties

        private readonly WorkflowDbContext _dbContext;

        #endregion


        #region Public Methods

        public async Task<WorkflowTask> GetWorkflowTaskById(Guid workflowTaskId)
        {
            if (workflowTaskId == default)
            {
                throw new ArgumentNullException(nameof(workflowTaskId));
            }

            var task = await _dbContext.WorkflowTasks
                .FirstOrDefaultAsync(x => x.Id == workflowTaskId);

            return task;
        }


        public async Task AddTask(WorkflowTask workflowTask)
        {
            if (workflowTask == null)
            {
                throw new ArgumentNullException(nameof(workflowTask));
            }

            await _dbContext.WorkflowTasks.AddAsync(workflowTask);
            await _dbContext.SaveChangesAsync();
        }


        public async Task UpdateTask(WorkflowTask workflowTask)
        {
            throw new NotImplementedException();
        }


        public async Task RemoveTask(Guid workflowTaskId)
        {
            throw new NotImplementedException();
        }


        public async Task<IEnumerable<WorkflowTask>> GetWorkflowTasksForUser(Guid userId)
        {
            var task = await _dbContext.WorkflowTasks
               .Where(x => x.Id == userId).ToListAsync();
            return task;
        }

        #endregion
    }
}
