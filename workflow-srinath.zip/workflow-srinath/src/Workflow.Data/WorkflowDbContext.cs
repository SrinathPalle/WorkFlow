﻿using System;
using Microsoft.EntityFrameworkCore;
using Workflow.Core.Domain;

namespace Workflow.Data
{
    public class WorkflowDbContext
        : DbContext
    {

        #region Constructor

            public WorkflowDbContext(DbContextOptions<WorkflowDbContext> options)
                : base(options)
            {
                var folder = Environment.SpecialFolder.LocalApplicationData;
                var path = Environment.GetFolderPath(folder);

                _dbPath = @"C:\Users\SrinathReddyPalle\Downloads\workflow.db";
            }

        #endregion


        #region Public Properties

            public DbSet<UserTable> Users { get; set; }

            public DbSet<WorkflowTask> WorkflowTasks { get; set; }

        #endregion


        #region Private Properties

            private string _dbPath;

        #endregion


        #region Protected Methods

            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                modelBuilder.Entity<UserTable>(eb =>
                {
                    eb.ToTable("UserTable");
                    eb.HasKey(c => c.Id);
                    eb.Property(c => c.Id).ValueGeneratedOnAdd();
                });

                modelBuilder.Entity<WorkflowTask>(eb =>
                {
                    eb.ToTable("WorkflowTask");
                    eb.HasKey(c => c.Id);
                    eb.Property(c => c.Id).ValueGeneratedOnAdd();
                });
            }


            protected override void OnConfiguring(DbContextOptionsBuilder options)
                => options.UseSqlite($"Data Source={_dbPath}");

        #endregion
    }
}
