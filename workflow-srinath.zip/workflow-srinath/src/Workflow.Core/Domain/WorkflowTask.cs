﻿using System;

namespace Workflow.Core.Domain
{
    public class WorkflowTask
        : Entity
    {
        public string Title { get; set; }
    }
}
