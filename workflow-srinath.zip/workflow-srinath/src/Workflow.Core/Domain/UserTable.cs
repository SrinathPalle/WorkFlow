﻿namespace Workflow.Core.Domain
{
    public class UserTable
        : Entity
    {
        public string Firstname { get; set; }

        public string Lastname { get; set; }

        public string Email { get; set; }
    }
}
