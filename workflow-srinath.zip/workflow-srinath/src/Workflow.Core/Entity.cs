﻿using System;

namespace Workflow.Core
{
    public class Entity
    {
        public Guid Id { get; set; }
    }
}
