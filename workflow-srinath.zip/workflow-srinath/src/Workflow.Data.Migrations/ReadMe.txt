﻿To Add a new migration:
Add-Migration -Context WorkflowDbContext -StartupProject Workflow.Data.Migrations -Project Workflow.Data.Migrations [MIGRATION_NAME]

To Remove the last migration or remove a specific migration:
Remove-Migration -Context WorkflowDbContext -StartupProject Workflow.Data.Migrations -Project Workflow.Data.Migrations [MIGRATION_NAME (optional)]

To sync changes to the database:
Update-Database -Context WorkflowDbContext -StartupProject Workflow.Data.Migrations -Project Workflow.Data.Migrations

To script migration from one migraton to another one
Script-Migration has two properties -To <starting-migration> and -From <ending-migration>
Note the <starting-migration> and the <ending-migration> must include the date time stamp ex. "20200409010145_Migration_x"
Script-Migration -Context WorkflowDbContext -StartupProject Workflow.Data.Migrations -Project Workflow.Data.Migrations -To [MIGRATION_NAME] -From [MIGRATION_NAME]