﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Workflow.FrontEnd.Objects
{
    public class TaskDetails
    {
        public string title { get; set; }
        public string id { get; set; }
    }
}