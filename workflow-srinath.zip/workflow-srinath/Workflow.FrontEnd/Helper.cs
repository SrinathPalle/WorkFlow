﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace Workflow.FrontEnd
{
    public static class Helper
    {
        public static async Task<HttpResponseMessage> InvokeBackendRestApiAsync(string baseUrl, string jsonFileStr, Method method)
        {
            var response = new HttpResponseMessage();
            var client = new RestClient(baseUrl);

            var request = new RestRequest
            {
                Method = method
            };
            if (method == Method.Post || method == Method.Put)
            {
                request.AddStringBody(jsonFileStr, "application/json");

            }
            var restResponse = await client.ExecuteAsync(request);
            response.StatusCode = restResponse.StatusCode;
            response.Content = new StringContent(restResponse.Content);
            return response;
        }
    }
}