﻿using Microsoft.Ajax.Utilities;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json.Serialization;
using System.Text.Json;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;
using Workflow.FrontEnd.Objects;
using System.Globalization;

namespace Workflow.FrontEnd.Frontend
{
    public partial class GetUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected async void btnGetUser_Click(object sender, EventArgs e)
        {
            string Id = txtIdSearch.Text.ToString();
            var res = await Helper.InvokeBackendRestApiAsync("http://localhost:5204/api/User/" + Id, "", Method.Get);
            var result = JsonSerializer.Deserialize<UserDetails>(res.Content.ReadAsStringAsync().Result.ToString(CultureInfo.InvariantCulture));
            List<UserDetails> list = new List<UserDetails>{ result };
            gdvUserDetails.DataSource = list;
            gdvUserDetails.DataBind();
        }
    }
}