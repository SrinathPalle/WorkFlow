﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Workflow.FrontEnd.Objects;

namespace Workflow.FrontEnd.Frontend
{
    public partial class GetWorkFlowTasksForUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected async void btnGetTask_ClickAsync(object sender, EventArgs e)
        {
            string Id = txtIdSearch.Text.ToString();
            var res = await Helper.InvokeBackendRestApiAsync("http://localhost:5204/api/WorkFlowTask/" + Id+"/tasks", "", Method.Get);
            var result = JsonSerializer.Deserialize<List<TaskDetails>>(res.Content.ReadAsStringAsync().Result.ToString(CultureInfo.InvariantCulture));
            gdvTaskDetails.DataSource = result;
            gdvTaskDetails.DataBind();
        }
    }
}