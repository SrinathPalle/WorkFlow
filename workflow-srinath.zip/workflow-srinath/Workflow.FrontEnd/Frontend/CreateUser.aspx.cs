﻿using Microsoft.Ajax.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RestSharp;
using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Workflow.FrontEnd.Objects;
using Workflow.Services;
using Workflow.Services.Interfaces;
using ServiceCollection = Microsoft.Extensions.DependencyInjection.ServiceCollection;

namespace Workflow.FrontEnd.Frontend
{
    public partial class CreateUser : System.Web.UI.Page
    {
        public CreateUser()
        {
            this.AsyncMode = true;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            //no implementation
        }

        protected async void btnCreate_Click(object sender, EventArgs e)
        {
            UserDetails userDetails = new UserDetails();
            userDetails.firstname = txtFirstName.Text.ToString();
            userDetails.lastname = txtLastName.Text.ToString();
            userDetails.email = txtEmail.Text.ToString();
            bool x = await validations(userDetails);
            if (x)
            {
                userDetails.id = Guid.NewGuid();
                var res = await Helper.InvokeBackendRestApiAsync("http://localhost:5204/api/User", JsonSerializer.Serialize(userDetails), Method.Post);
                if (res.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    lblCreateMessage.Visible = true;
                    lblCreateMessage.Text = "Succeddfully created user with Id:" + userDetails.id;
                }
            }
            else
            {
                lblCreateMessage.Visible = true;
                lblCreateMessage.Text = "Email Id/FirstName and LastName is not available.";
            }
        }

        private async Task<bool> validations(UserDetails user)
        {
            var res = await Helper.InvokeBackendRestApiAsync("http://localhost:5204/api/User/" + user.email + "/email", "", Method.Get);
            if (res.StatusCode == System.Net.HttpStatusCode.NoContent)
            {
                var result = await Helper.InvokeBackendRestApiAsync("http://localhost:5204/api/User/" + user.firstname + "/" + user.lastname, "", Method.Get);
                if (result.StatusCode == System.Net.HttpStatusCode.NoContent)
                {
                    return true;

                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
    }
}