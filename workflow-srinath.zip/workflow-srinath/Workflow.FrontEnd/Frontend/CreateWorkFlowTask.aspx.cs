﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Workflow.FrontEnd.Objects;

namespace Workflow.FrontEnd.Frontend
{
    public partial class CreateWorkFlowTask : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected async void btnCreate_Click(object sender, EventArgs e)
        {

            TaskDetails taskDetails = new TaskDetails();
            taskDetails.title = txtTitle.Text.ToString();
            taskDetails.id = txtId.Text.ToString();
            var res = await Helper.InvokeBackendRestApiAsync("http://localhost:5204/api/WorkFlowTask", JsonSerializer.Serialize(taskDetails), Method.Post);
            //lblCreateMessage.Visible = true;
            //lblCreateMessage.Text = "Email Id/FirstName and LastName is not available.";
        }
    }
}