﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Workflow.FrontEnd.Objects;

namespace Workflow.FrontEnd.Frontend
{
    public partial class UpdateUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected async void btnUpdate_ClickAsync(object sender, EventArgs e)
        {
            UserDetails userDetails = new UserDetails();
            userDetails.firstname = txtFirstName.Text.ToString();
            userDetails.lastname = txtLastName.Text.ToString();
            userDetails.email = txtEmail.Text.ToString();
            userDetails.id = new Guid(txtId.Text.ToString());
            var res = await Helper.InvokeBackendRestApiAsync("http://localhost:5204/api/User/" + userDetails.id, JsonSerializer.Serialize(userDetails), Method.Put);
            if (res.StatusCode == System.Net.HttpStatusCode.OK)
            {
                lblMessage.Visible = true;

                lblMessage.Text = "Updated " + userDetails.id + " successfully.";

            }
        }
    }
}