﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Workflow.FrontEnd.Objects;

namespace Workflow.FrontEnd.Frontend
{
    public partial class DeleteUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected async void btnDeleteUser_Click(object sender, EventArgs e)
        {
            string Id = txtIdSearch.Text.ToString();
            var res = await Helper.InvokeBackendRestApiAsync("http://localhost:5204/api/User/" + Id, "", Method.Delete);
            if (res.StatusCode == System.Net.HttpStatusCode.OK)
            {
                lblDeleteMessage.Visible = true;
                lblDeleteMessage.Text = "Deleted UserId: " + Id + " Successfully.";
            }
        }
    }
}